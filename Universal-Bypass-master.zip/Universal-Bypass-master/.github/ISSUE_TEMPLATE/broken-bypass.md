---
name: Broken Bypass
about: A bypass is no longer working or misbehaving
title: 'ENTER DOMAIN HERE'
labels: 'broken bypass'

---

Before you report a broken bypass, please use the search function to ensure that there are no other open issues regarding that site: https://github.com/Sainan/Universal-Bypass/issues?utf8=%E2%9C%93&q=ENTER+DOMAIN+HERE
I know it can be frustrating, but creating 10 issues regarding the same problem doesn't help.

If that is not the case, please **provide an example link.** We need to be able to see what has gone wrong in order to fix it.
